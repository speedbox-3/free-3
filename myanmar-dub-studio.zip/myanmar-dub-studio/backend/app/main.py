from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import GEMINI_VOICES, get_settings
from app.database import init_db
from app.routers import jobs, upload

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(title="Myanmar AI Recap & Dubbing Studio", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list or ["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload.router)
app.include_router(jobs.router)


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.get("/api/voices")
async def voices():
    return {"voices": GEMINI_VOICES}
