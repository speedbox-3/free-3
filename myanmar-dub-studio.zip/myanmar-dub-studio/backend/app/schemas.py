from pydantic import BaseModel, Field


class JobOptions(BaseModel):
    voice_name: str = "Kore"
    speed: float = Field(1.0, ge=0.5, le=2.0)
    pitch_semitones: float = Field(0.0, ge=-6.0, le=6.0)
    subtitle_mode: str = Field("soft", pattern="^(off|soft|burned)$")
    make_recap: bool = False


class JobResponse(BaseModel):
    id: str
    original_filename: str
    status: str
    progress: int
    error_message: str | None = None

    model_config = {"from_attributes": True}


class JobDetail(JobResponse):
    voice_name: str
    speed: float
    pitch_semitones: float
    subtitle_mode: str
    make_recap: bool
    transcript_original: str | None = None
    transcript_clean: str | None = None
    transcript_myanmar: str | None = None
    recap_text: str | None = None
    output_path: str | None = None
