import enum
import uuid
from datetime import datetime

from sqlalchemy import DateTime, Enum, Float, Integer, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


class JobStatus(str, enum.Enum):
    queued = "queued"
    extracting_audio = "extracting_audio"
    transcribing = "transcribing"
    cleaning_translating = "cleaning_translating"
    generating_recap = "generating_recap"
    dubbing = "dubbing"
    merging_video = "merging_video"
    done = "done"
    failed = "failed"


class Job(Base):
    __tablename__ = "jobs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    original_filename: Mapped[str] = mapped_column(String(512))
    status: Mapped[JobStatus] = mapped_column(Enum(JobStatus), default=JobStatus.queued)
    progress: Mapped[int] = mapped_column(Integer, default=0)  # 0-100
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)

    # pipeline options
    target_language: Mapped[str] = mapped_column(String(16), default="my")  # my = Myanmar/Burmese
    voice_name: Mapped[str] = mapped_column(String(32), default="Kore")
    speed: Mapped[float] = mapped_column(Float, default=1.0)   # 0.5 - 2.0
    pitch_semitones: Mapped[float] = mapped_column(Float, default=0.0)  # -6..+6
    subtitle_mode: Mapped[str] = mapped_column(String(16), default="soft")  # "off" | "soft" | "burned"
    make_recap: Mapped[bool] = mapped_column(default=False)

    # pipeline artifacts
    source_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    audio_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    transcript_original: Mapped[str | None] = mapped_column(Text, nullable=True)
    transcript_clean: Mapped[str | None] = mapped_column(Text, nullable=True)
    transcript_myanmar: Mapped[str | None] = mapped_column(Text, nullable=True)
    recap_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    dubbed_audio_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    subtitle_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)
    output_path: Mapped[str | None] = mapped_column(String(1024), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
