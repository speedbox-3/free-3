from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models import Job, JobStatus
from app.services import audio_extract, gemini_service, subtitle, transcription, tts_service, video_merge

settings = get_settings()


async def _set(db: AsyncSession, job: Job, **fields) -> None:
    for k, v in fields.items():
        setattr(job, k, v)
    await db.commit()
    await db.refresh(job)


async def run_pipeline(job_id: str, db: AsyncSession) -> None:
    job = await db.get(Job, job_id)
    if job is None:
        return

    work_dir = Path(settings.storage_dir) / "work" / job.id
    work_dir.mkdir(parents=True, exist_ok=True)

    try:
        # 1. Extract audio
        await _set(db, job, status=JobStatus.extracting_audio, progress=5)
        audio_path = str(work_dir / "audio.wav")
        await audio_extract.extract_audio(job.source_path, audio_path)
        duration = await audio_extract.probe_duration_seconds(job.source_path)
        await _set(db, job, audio_path=audio_path, progress=15)

        # 2. Transcribe original audio
        await _set(db, job, status=JobStatus.transcribing, progress=20)
        segments = await transcription.transcribe(audio_path)
        transcript_original = "\n".join(s["text"] for s in segments)
        await _set(db, job, transcript_original=transcript_original, progress=40)

        # 3. Clean + translate (per-segment, to keep timing) + optional recap
        await _set(db, job, status=JobStatus.cleaning_translating, progress=45)
        clean_text = await gemini_service.clean_transcript(transcript_original)
        segments_my = await gemini_service.segment_myanmar_translation(segments)
        transcript_myanmar = "\n".join(s["text_my"] for s in segments_my)
        await _set(
            db, job,
            transcript_clean=clean_text,
            transcript_myanmar=transcript_myanmar,
            progress=55,
        )

        if job.make_recap:
            await _set(db, job, status=JobStatus.generating_recap, progress=58)
            recap = await gemini_service.generate_recap(clean_text, target_language=job.target_language)
            await _set(db, job, recap_text=recap, progress=62)

        # 4. Dub to Myanmar speech, timed to original segments
        await _set(db, job, status=JobStatus.dubbing, progress=65)
        dubbed_audio_path = str(work_dir / "dubbed.wav")
        await tts_service.build_dubbed_track(
            segments_my,
            voice_name=job.voice_name,
            speed=job.speed,
            pitch_semitones=job.pitch_semitones,
            total_duration_seconds=duration,
            work_dir=work_dir / "segments",
            out_path=Path(dubbed_audio_path),
        )
        await _set(db, job, dubbed_audio_path=dubbed_audio_path, progress=80)

        # 5. Subtitles (optional)
        subtitle_path = None
        if job.subtitle_mode != "off":
            subtitle_path = str(work_dir / "myanmar.srt")
            subtitle.write_srt(segments_my, subtitle_path, text_key="text_my")
            await _set(db, job, subtitle_path=subtitle_path, progress=85)

        # 6. Merge original video + dubbed audio (+ subtitles)
        await _set(db, job, status=JobStatus.merging_video, progress=88)
        output_path = str(Path(settings.storage_dir) / "outputs" / f"{job.id}.mp4")
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        await video_merge.merge_video(
            job.source_path,
            dubbed_audio_path,
            output_path,
            subtitle_path=subtitle_path,
            subtitle_mode=job.subtitle_mode,
        )

        await _set(db, job, status=JobStatus.done, progress=100, output_path=output_path)

    except Exception as exc:  # noqa: BLE001
        await _set(db, job, status=JobStatus.failed, error_message=str(exc)[:2000])
        raise
