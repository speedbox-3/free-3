"""
Round-robin + failover across API keys *you own* for a given provider.

This exists so a batch job doesn't grind to a halt because one of your keys
is temporarily rate-limited — it rotates to your next key and puts the
throttled one on a short cooldown before retrying it. It intentionally does
NOT try to auto-create or discover additional free-tier accounts; add keys
here that are actually yours and that you're allowed to use per each
provider's terms.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from itertools import cycle
from threading import Lock


@dataclass
class _KeyState:
    key: str
    cooldown_until: float = 0.0


class KeyPool:
    def __init__(self, keys: list[str], cooldown_seconds: float = 30.0):
        if not keys:
            raise ValueError("KeyPool needs at least one API key configured")
        self._states = [_KeyState(k) for k in keys]
        self._cycle = cycle(self._states)
        self._cooldown = cooldown_seconds
        self._lock = Lock()

    def get_key(self) -> str:
        """Return the next available (not-in-cooldown) key."""
        with self._lock:
            now = time.time()
            for _ in range(len(self._states)):
                state = next(self._cycle)
                if state.cooldown_until <= now:
                    return state.key
            # everything is cooling down: return the one closest to ready
            soonest = min(self._states, key=lambda s: s.cooldown_until)
            return soonest.key

    def report_rate_limited(self, key: str) -> None:
        with self._lock:
            for state in self._states:
                if state.key == key:
                    state.cooldown_until = time.time() + self._cooldown
                    break

    @property
    def size(self) -> int:
        return len(self._states)


_pools: dict[str, KeyPool] = {}


def get_pool(name: str, keys: list[str]) -> KeyPool:
    if name not in _pools:
        _pools[name] = KeyPool(keys)
    return _pools[name]
