import asyncio
import shlex


class MergeError(RuntimeError):
    pass


async def _run(cmd: str) -> None:
    proc = await asyncio.create_subprocess_shell(
        cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise MergeError(stderr.decode(errors="ignore")[-4000:])


async def merge_video(
    original_video_path: str,
    dubbed_audio_path: str,
    output_path: str,
    subtitle_path: str | None = None,
    subtitle_mode: str = "soft",  # "off" | "soft" | "burned"
) -> None:
    video = shlex.quote(original_video_path)
    audio = shlex.quote(dubbed_audio_path)
    out = shlex.quote(output_path)

    if subtitle_mode == "burned" and subtitle_path:
        # Burn subtitles into the picture: re-encodes video, so it takes longer
        # but the captions are guaranteed visible regardless of the player.
        sub = shlex.quote(subtitle_path)
        vf = f"subtitles={sub}:force_style='FontName=Noto Sans Myanmar,FontSize=20'"
        cmd = (
            f'ffmpeg -y -i {video} -i {audio} -vf "{vf}" '
            f"-map 0:v:0 -map 1:a:0 -c:v libx264 -c:a aac -shortest {out}"
        )
    elif subtitle_mode == "soft" and subtitle_path:
        # Soft subtitle track: video is copied untouched (fast), player can toggle it on/off.
        sub = shlex.quote(subtitle_path)
        cmd = (
            f"ffmpeg -y -i {video} -i {audio} -i {sub} "
            f"-map 0:v:0 -map 1:a:0 -map 2:s:0 "
            f"-c:v copy -c:a aac -c:s mov_text -shortest {out}"
        )
    else:
        # No subtitles at all.
        cmd = f"ffmpeg -y -i {video} -i {audio} -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -shortest {out}"

    await _run(cmd)
