def _srt_timestamp(seconds: float) -> str:
    if seconds < 0:
        seconds = 0
    hours, rem = divmod(seconds, 3600)
    minutes, sec = divmod(rem, 60)
    whole_sec = int(sec)
    millis = int(round((sec - whole_sec) * 1000))
    return f"{int(hours):02d}:{int(minutes):02d}:{whole_sec:02d},{millis:03d}"


def build_srt(segments: list[dict], text_key: str = "text_my") -> str:
    """segments: [{"start": float, "end": float, <text_key>: str}, ...]"""
    lines = []
    for i, seg in enumerate(segments, start=1):
        text = seg.get(text_key, "").strip()
        if not text:
            continue
        lines.append(str(i))
        lines.append(f"{_srt_timestamp(seg['start'])} --> {_srt_timestamp(seg['end'])}")
        lines.append(text)
        lines.append("")
    return "\n".join(lines)


def write_srt(segments: list[dict], out_path: str, text_key: str = "text_my") -> None:
    content = build_srt(segments, text_key=text_key)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)
