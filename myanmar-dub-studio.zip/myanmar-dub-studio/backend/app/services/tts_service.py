"""
Myanmar dubbing:
  1. Gemini TTS synthesizes each translated segment individually (24kHz mono PCM WAV).
  2. Each segment's speed/pitch is adjusted with ffmpeg (Gemini TTS itself is steered by
     natural-language style prompts, not numeric params, so precise speed/pitch control
     happens here instead).
  3. Segments are placed at their original timestamps (adelay) and mixed into one track
     the length of the source video — this is a timing-alignment approach to "lip-sync"
     (segments start/end roughly where the original speech did), not phoneme-level sync.
"""
from __future__ import annotations

import asyncio
import base64
import shlex
import struct
import uuid
from pathlib import Path

import httpx

from app.config import get_settings
from app.services.key_manager import get_pool

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models"
SAMPLE_RATE = 24000

# BCP-47 code Gemini TTS uses to steer output toward Burmese.
MYANMAR_LOCALE = "my-MM"


class TTSError(RuntimeError):
    pass


def _pcm_to_wav(pcm_bytes: bytes) -> bytes:
    channels, sample_width, rate = 1, 2, SAMPLE_RATE
    byte_rate = rate * channels * sample_width
    block_align = channels * sample_width
    data_size = len(pcm_bytes)
    header = struct.pack(
        "<4sI4s4sIHHIIHH4sI",
        b"RIFF", 36 + data_size, b"WAVE", b"fmt ", 16, 1, channels,
        rate, byte_rate, block_align, sample_width * 8, b"data", data_size,
    )
    return header + pcm_bytes


async def _synthesize_raw(text: str, voice_name: str) -> bytes:
    settings = get_settings()
    pool = get_pool("gemini", settings.gemini_keys)
    key = pool.get_key()
    url = f"{GEMINI_BASE}/{settings.gemini_tts_model}:generateContent"

    body = {
        "contents": [{"parts": [{"text": text}]}],
        "generationConfig": {
            "responseModalities": ["AUDIO"],
            "speechConfig": {
                "languageCode": MYANMAR_LOCALE,
                "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice_name}},
            },
        },
    }

    async with httpx.AsyncClient(timeout=90) as client:
        resp = await client.post(
            url, headers={"x-goog-api-key": key, "Content-Type": "application/json"}, json=body
        )
        if resp.status_code == 429:
            pool.report_rate_limited(key)
            raise TTSError("gemini tts rate limited")
        resp.raise_for_status()
        data = resp.json()

    try:
        b64_audio = data["candidates"][0]["content"]["parts"][0]["inlineData"]["data"]
    except (KeyError, IndexError) as exc:
        raise TTSError(f"Unexpected Gemini TTS response shape: {data}") from exc

    return base64.b64decode(b64_audio)


async def _run_ffmpeg(cmd: str) -> None:
    proc = await asyncio.create_subprocess_shell(
        cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise TTSError(stderr.decode(errors="ignore")[-4000:])


async def _apply_speed_pitch(in_path: Path, out_path: Path, speed: float, pitch_semitones: float) -> None:
    pitch_factor = 2 ** (pitch_semitones / 12.0)
    tempo_after_pitch = max(0.5, min(2.0, speed / pitch_factor))
    filters = f"asetrate={int(SAMPLE_RATE * pitch_factor)},aresample={SAMPLE_RATE},atempo={tempo_after_pitch:.4f}"
    cmd = f"ffmpeg -y -i {shlex.quote(str(in_path))} -filter:a \"{filters}\" {shlex.quote(str(out_path))}"
    await _run_ffmpeg(cmd)


async def synthesize_segment(text: str, voice_name: str, speed: float, pitch_semitones: float, work_dir: Path) -> Path:
    raw_pcm = await _synthesize_raw(text, voice_name)
    wav_bytes = _pcm_to_wav(raw_pcm)

    raw_path = work_dir / f"seg_{uuid.uuid4().hex}_raw.wav"
    raw_path.write_bytes(wav_bytes)

    if speed == 1.0 and pitch_semitones == 0.0:
        return raw_path

    final_path = work_dir / f"seg_{uuid.uuid4().hex}_final.wav"
    await _apply_speed_pitch(raw_path, final_path, speed, pitch_semitones)
    return final_path


async def build_dubbed_track(
    segments: list[dict],
    voice_name: str,
    speed: float,
    pitch_semitones: float,
    total_duration_seconds: float,
    work_dir: Path,
    out_path: Path,
) -> None:
    """segments: list of {"start": float, "end": float, "text_my": str}"""
    work_dir.mkdir(parents=True, exist_ok=True)

    segment_paths: list[tuple[float, Path]] = []
    for seg in segments:
        if not seg.get("text_my", "").strip():
            continue
        path = await synthesize_segment(seg["text_my"], voice_name, speed, pitch_semitones, work_dir)
        segment_paths.append((seg["start"], path))

    if not segment_paths:
        raise TTSError("No dubbed segments were produced")

    inputs = " ".join(f"-i {shlex.quote(str(p))}" for _, p in segment_paths)
    delayed = "".join(
        f"[{i}:a]adelay={int(start * 1000)}|{int(start * 1000)}[a{i}];"
        for i, (start, _) in enumerate(segment_paths)
    )
    mix_inputs = "".join(f"[a{i}]" for i in range(len(segment_paths)))
    filter_complex = (
        f"{delayed}{mix_inputs}amix=inputs={len(segment_paths)}:dropout_transition=0:normalize=0[mixed]"
    )

    cmd = (
        f"ffmpeg -y {inputs} -filter_complex \"{filter_complex}\" -map \"[mixed]\" "
        f"-t {total_duration_seconds:.3f} {shlex.quote(str(out_path))}"
    )
    await _run_ffmpeg(cmd)
