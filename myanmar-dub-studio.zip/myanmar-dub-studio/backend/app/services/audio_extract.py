import asyncio
import shlex


class FFmpegError(RuntimeError):
    pass


async def _run(cmd: str) -> None:
    proc = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise FFmpegError(stderr.decode(errors="ignore")[-4000:])


async def probe_duration_seconds(video_path: str) -> float:
    cmd = (
        f"ffprobe -v error -show_entries format=duration "
        f"-of default=noprint_wrappers=1:nokey=1 {shlex.quote(video_path)}"
    )
    proc = await asyncio.create_subprocess_shell(
        cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise FFmpegError(stderr.decode(errors="ignore"))
    return float(stdout.decode().strip() or 0.0)


async def extract_audio(video_path: str, audio_out_path: str) -> None:
    """Extract mono 16kHz WAV audio from an mp4 — the format most STT APIs expect."""
    cmd = (
        f"ffmpeg -y -i {shlex.quote(video_path)} "
        f"-vn -ac 1 -ar 16000 -acodec pcm_s16le {shlex.quote(audio_out_path)}"
    )
    await _run(cmd)
