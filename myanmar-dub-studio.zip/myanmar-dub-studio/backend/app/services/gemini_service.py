"""
Text-side Gemini calls: cleaning up a raw ASR transcript, translating it to
Myanmar/Burmese, and (optionally) producing a short recap/summary.

Note on scope: the "rewrite" step here is a *narration-style* pass — fixing
filler words, run-ons, and ASR artifacts so the text reads naturally when
spoken aloud by the dub. It is not intended as a way to disguise someone
else's copyrighted script; only run this on content you have the rights to
adapt.
"""
from __future__ import annotations

import json

import httpx

from app.config import get_settings
from app.services.key_manager import get_pool

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models"


class GeminiError(RuntimeError):
    pass


async def _generate_text(prompt: str) -> str:
    settings = get_settings()
    pool = get_pool("gemini", settings.gemini_keys)
    key = pool.get_key()
    url = f"{GEMINI_BASE}/{settings.gemini_text_model}:generateContent"

    async with httpx.AsyncClient(timeout=90) as client:
        resp = await client.post(
            url,
            headers={"x-goog-api-key": key, "Content-Type": "application/json"},
            json={"contents": [{"parts": [{"text": prompt}]}]},
        )
        if resp.status_code == 429:
            pool.report_rate_limited(key)
            raise GeminiError("gemini rate limited")
        resp.raise_for_status()
        data = resp.json()

    try:
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()
    except (KeyError, IndexError) as exc:
        raise GeminiError(f"Unexpected Gemini response shape: {data}") from exc


async def clean_transcript(raw_text: str) -> str:
    prompt = (
        "Clean up this raw speech-to-text transcript for read-aloud narration: "
        "remove filler words (um, uh), fix obvious ASR mis-hearings, fix punctuation "
        "and sentence breaks. Keep the original meaning and every fact exactly as-is. "
        "Return ONLY the cleaned text, no commentary.\n\n"
        f"TRANSCRIPT:\n{raw_text}"
    )
    return await _generate_text(prompt)


async def translate_to_myanmar(clean_text: str) -> str:
    prompt = (
        "Translate the following text into natural, conversational Myanmar (Burmese). "
        "Keep names and numbers accurate. Return ONLY the Myanmar translation, no commentary.\n\n"
        f"TEXT:\n{clean_text}"
    )
    return await _generate_text(prompt)


async def generate_recap(clean_text: str, target_language: str = "en") -> str:
    lang_instruction = (
        "Write the recap in Myanmar (Burmese)." if target_language == "my" else "Write the recap in English."
    )
    prompt = (
        "Summarize the following transcript into a concise, engaging recap (under 200 words) "
        "covering only what actually happens/is said — no invented details. "
        f"{lang_instruction} Return ONLY the recap text.\n\n"
        f"TRANSCRIPT:\n{clean_text}"
    )
    return await _generate_text(prompt)


async def segment_myanmar_translation(segments: list[dict]) -> list[dict]:
    """
    Translate each timed segment individually so timing/subtitle alignment is
    preserved (rather than translating the whole transcript as one blob and
    losing the per-line timestamps).
    """
    numbered = "\n".join(f"{i}: {seg['text']}" for i, seg in enumerate(segments))
    prompt = (
        "Translate each numbered line into natural Myanmar (Burmese). "
        "Return ONLY a JSON array of strings, same order, same length, no numbering, no commentary.\n\n"
        f"{numbered}"
    )
    raw = await _generate_text(prompt)
    raw = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    try:
        translations = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise GeminiError(f"Could not parse per-segment translation JSON: {raw[:300]}") from exc

    if len(translations) != len(segments):
        raise GeminiError("Translation segment count mismatch")

    return [
        {"start": seg["start"], "end": seg["end"], "text": seg["text"], "text_my": t}
        for seg, t in zip(segments, translations)
    ]
