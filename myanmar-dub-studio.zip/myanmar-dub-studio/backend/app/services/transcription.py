"""
Speech-to-text: Gladia async API first, falls back to Groq's Whisper endpoint
if Gladia is unavailable / all keys are cooling down / USE_GROQ_FALLBACK is set
and Gladia errors out.

Returns a list of segments: [{"start": float, "end": float, "text": str}, ...]
so downstream steps (subtitles, per-segment dubbing/timing) have something to
line up against.
"""
from __future__ import annotations

import asyncio
from typing import Any

import httpx

from app.config import get_settings
from app.services.key_manager import get_pool

GLADIA_BASE = "https://api.gladia.io/v2"
GROQ_TRANSCRIBE_URL = "https://api.groq.com/openai/v1/audio/transcriptions"


class TranscriptionError(RuntimeError):
    pass


async def _gladia_transcribe(audio_path: str) -> list[dict[str, Any]]:
    settings = get_settings()
    pool = get_pool("gladia", settings.gladia_keys)
    key = pool.get_key()
    headers = {"x-gladia-key": key}

    async with httpx.AsyncClient(timeout=120) as client:
        with open(audio_path, "rb") as f:
            files = {"audio": (audio_path.split("/")[-1], f, "audio/wav")}
            upload_resp = await client.post(f"{GLADIA_BASE}/upload", headers=headers, files=files)
        if upload_resp.status_code == 429:
            pool.report_rate_limited(key)
            raise TranscriptionError("gladia rate limited on upload")
        upload_resp.raise_for_status()
        audio_url = upload_resp.json()["audio_url"]

        start_resp = await client.post(
            f"{GLADIA_BASE}/transcription",
            headers=headers,
            json={"audio_url": audio_url, "diarization": False},
        )
        if start_resp.status_code == 429:
            pool.report_rate_limited(key)
            raise TranscriptionError("gladia rate limited on transcription start")
        start_resp.raise_for_status()
        result_url = start_resp.json()["result_url"]

        for _ in range(120):  # ~10 min max for a few-minute clip
            poll = await client.get(result_url, headers=headers)
            poll.raise_for_status()
            data = poll.json()
            if data.get("status") == "done":
                utterances = data["result"]["transcription"]["utterances"]
                return [
                    {"start": u["start"], "end": u["end"], "text": u["text"].strip()}
                    for u in utterances
                ]
            if data.get("status") == "error":
                raise TranscriptionError(str(data.get("error")))
            await asyncio.sleep(5)

    raise TranscriptionError("gladia transcription timed out")


async def _groq_transcribe(audio_path: str) -> list[dict[str, Any]]:
    settings = get_settings()
    pool = get_pool("groq", settings.groq_keys)
    key = pool.get_key()
    headers = {"Authorization": f"Bearer {key}"}

    async with httpx.AsyncClient(timeout=180) as client:
        with open(audio_path, "rb") as f:
            files = {"file": (audio_path.split("/")[-1], f, "audio/wav")}
            data = {"model": "whisper-large-v3", "response_format": "verbose_json"}
            resp = await client.post(GROQ_TRANSCRIBE_URL, headers=headers, files=files, data=data)
        if resp.status_code == 429:
            pool.report_rate_limited(key)
            raise TranscriptionError("groq rate limited")
        resp.raise_for_status()
        payload = resp.json()

    segments = payload.get("segments") or []
    if segments:
        return [{"start": s["start"], "end": s["end"], "text": s["text"].strip()} for s in segments]
    # verbose_json without segment timing (rare) -> single blob
    return [{"start": 0.0, "end": 0.0, "text": payload.get("text", "").strip()}]


async def transcribe(audio_path: str) -> list[dict[str, Any]]:
    settings = get_settings()
    if settings.gladia_keys:
        try:
            return await _gladia_transcribe(audio_path)
        except Exception as exc:  # noqa: BLE001 - deliberately broad, we fall back
            if not (settings.use_groq_fallback and settings.groq_keys):
                raise TranscriptionError(f"Gladia failed and no fallback configured: {exc}") from exc
    if settings.groq_keys:
        return await _groq_transcribe(audio_path)
    raise TranscriptionError("No STT provider configured (set GLADIA_API_KEYS or GROQ_API_KEYS)")
