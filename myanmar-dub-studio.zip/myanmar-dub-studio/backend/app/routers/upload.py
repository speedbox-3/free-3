import uuid
from pathlib import Path

from fastapi import APIRouter, BackgroundTasks, File, Form, HTTPException, UploadFile

from app.config import get_settings
from app.database import AsyncSessionLocal
from app.models import Job
from app.schemas import JobResponse
from app.services import audio_extract
from app.services.pipeline import run_pipeline

router = APIRouter(prefix="/api/jobs", tags=["jobs"])
settings = get_settings()


async def _save_upload(file: UploadFile) -> tuple[str, str]:
    if not file.filename or not file.filename.lower().endswith((".mp4", ".mov", ".m4v")):
        raise HTTPException(400, "Only .mp4/.mov/.m4v files are supported")

    job_id = str(uuid.uuid4())
    upload_dir = Path(settings.storage_dir) / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    dest = upload_dir / f"{job_id}.mp4"

    size = 0
    max_bytes = settings.max_upload_mb * 1024 * 1024
    with open(dest, "wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > max_bytes:
                out.close()
                dest.unlink(missing_ok=True)
                raise HTTPException(400, f"File exceeds {settings.max_upload_mb} MB limit")
            out.write(chunk)

    return job_id, str(dest)


async def _create_and_launch_job(
    file: UploadFile,
    voice_name: str,
    speed: float,
    pitch_semitones: float,
    subtitle_mode: str,
    make_recap: bool,
    background_tasks: BackgroundTasks,
) -> Job:
    job_id, dest = await _save_upload(file)

    duration = await audio_extract.probe_duration_seconds(dest)
    if duration > settings.max_video_seconds:
        Path(dest).unlink(missing_ok=True)
        raise HTTPException(
            400,
            f"Video is {duration:.0f}s, longer than the {settings.max_video_seconds}s limit for this instance",
        )

    async with AsyncSessionLocal() as db:
        job = Job(
            id=job_id,
            original_filename=file.filename,
            source_path=dest,
            voice_name=voice_name,
            speed=speed,
            pitch_semitones=pitch_semitones,
            subtitle_mode=subtitle_mode,
            make_recap=make_recap,
        )
        db.add(job)
        await db.commit()
        await db.refresh(job)

    background_tasks.add_task(_run_job_in_background, job_id)
    return job


async def _run_job_in_background(job_id: str) -> None:
    async with AsyncSessionLocal() as db:
        await run_pipeline(job_id, db)


@router.post("", response_model=JobResponse)
async def create_job(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    voice_name: str = Form("Kore"),
    speed: float = Form(1.0),
    pitch_semitones: float = Form(0.0),
    subtitle_mode: str = Form("soft"),
    make_recap: bool = Form(False),
):
    job = await _create_and_launch_job(
        file, voice_name, speed, pitch_semitones, subtitle_mode, make_recap, background_tasks
    )
    return job


@router.post("/batch", response_model=list[JobResponse])
async def create_batch(
    background_tasks: BackgroundTasks,
    files: list[UploadFile] = File(...),
    voice_name: str = Form("Kore"),
    speed: float = Form(1.0),
    pitch_semitones: float = Form(0.0),
    subtitle_mode: str = Form("soft"),
    make_recap: bool = Form(False),
):
    jobs = []
    for file in files:
        job = await _create_and_launch_job(
            file, voice_name, speed, pitch_semitones, subtitle_mode, make_recap, background_tasks
        )
        jobs.append(job)
    return jobs
