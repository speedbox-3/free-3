from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.models import Job
from app.schemas import JobDetail, JobResponse

router = APIRouter(prefix="/api/jobs", tags=["jobs"])
settings = get_settings()


@router.get("", response_model=list[JobResponse])
async def list_jobs(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Job).order_by(Job.created_at.desc()).limit(100))
    return result.scalars().all()


@router.get("/{job_id}", response_model=JobDetail)
async def get_job(job_id: str, db: AsyncSession = Depends(get_db)):
    job = await db.get(Job, job_id)
    if job is None:
        raise HTTPException(404, "Job not found")
    return job


@router.get("/{job_id}/download")
async def download_job(job_id: str, db: AsyncSession = Depends(get_db)):
    job = await db.get(Job, job_id)
    if job is None:
        raise HTTPException(404, "Job not found")
    if job.status != "done" or not job.output_path or not Path(job.output_path).exists():
        raise HTTPException(409, "Job isn't finished yet")
    return FileResponse(job.output_path, media_type="video/mp4", filename=f"{job.original_filename}_myanmar_dub.mp4")


@router.delete("/{job_id}")
async def delete_job(job_id: str, db: AsyncSession = Depends(get_db)):
    job = await db.get(Job, job_id)
    if job is None:
        raise HTTPException(404, "Job not found")
    for path in (job.source_path, job.output_path, job.audio_path, job.dubbed_audio_path, job.subtitle_path):
        if path:
            Path(path).unlink(missing_ok=True)
    await db.delete(job)
    await db.commit()
    return {"deleted": job_id}
