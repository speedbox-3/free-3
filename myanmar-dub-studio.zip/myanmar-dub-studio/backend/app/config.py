from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


def _split_keys(raw: str) -> list[str]:
    return [k.strip() for k in raw.split(",") if k.strip()]


# 24 Gemini prebuilt voices (language-agnostic; steered to Burmese via language_code).
GEMINI_VOICES = [
    "Zephyr", "Puck", "Charon", "Kore", "Fenrir", "Leda", "Orus", "Aoede",
    "Callirrhoe", "Autonoe", "Enceladus", "Iapetus", "Umbriel", "Algieba",
    "Despina", "Erinome", "Algenib", "Rasalgethi", "Laomedeia", "Achernar",
    "Alnilam", "Schedar", "Gacrux", "Pulcherrima",
]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # STT
    gladia_api_keys: str = ""
    groq_api_keys: str = ""
    use_groq_fallback: bool = True

    # Gemini
    gemini_api_keys: str = ""
    gemini_text_model: str = "gemini-2.5-flash"
    gemini_tts_model: str = "gemini-2.5-flash-preview-tts"

    # DB / queue
    database_url: str = "postgresql+asyncpg://recap:recap@localhost:5432/recap_studio"
    redis_url: str = "redis://localhost:6379/0"
    upstash_redis_rest_url: str = ""
    upstash_redis_rest_token: str = ""

    # Storage
    storage_backend: str = "local"  # "local" | "r2"
    storage_dir: str = "/app/storage"
    r2_account_id: str = ""
    r2_access_key_id: str = ""
    r2_secret_access_key: str = ""
    r2_bucket: str = ""

    # App
    cors_origins: str = "http://localhost:8080"
    max_upload_mb: int = 300
    max_video_seconds: int = 360

    @property
    def gladia_keys(self) -> list[str]:
        return _split_keys(self.gladia_api_keys)

    @property
    def groq_keys(self) -> list[str]:
        return _split_keys(self.groq_api_keys)

    @property
    def gemini_keys(self) -> list[str]:
        return _split_keys(self.gemini_api_keys)

    @property
    def cors_origin_list(self) -> list[str]:
        return _split_keys(self.cors_origins)


@lru_cache
def get_settings() -> Settings:
    return Settings()
