# Myanmar AI Recap & Dubbing Studio

One-click pipeline: **MP4 → audio extract (FFmpeg) → transcript (Gladia / Groq Whisper) → clean + translate + recap (Gemini) → Myanmar dub (Gemini TTS) → merged MP4 with optional burned-in or soft Myanmar subtitles.**

Built for **short clips (a few minutes each)** — your own videos, licensed content, or anything you have the rights to dub/recap. Batch upload, live progress, and a dark "2026 cyberpunk" UI.

> **Please use responsibly.** This tool re-dubs and recaps video. Only run it on content you own or are licensed to modify/redistribute — dubbing someone else's copyrighted film/show and reposting it isn't something this project is designed to help with, and doing so can carry real legal risk for you. See "About the API keys" below for a related note.

---

## Architecture

```
frontend/            Static HTML + Tailwind (CDN) + vanilla JS — upload, controls, progress, download
backend/app/
  main.py            FastAPI app + CORS + router registration
  config.py          Settings (env vars), multi-key lists per provider
  database.py        Async SQLAlchemy engine/session (Postgres)
  models.py          Job table (status, progress, transcript, paths, voice settings)
  routers/
    upload.py        POST /api/jobs (single + batch upload)
    jobs.py           GET  /api/jobs/{id}  (status/progress), /download, DELETE
  services/
    key_manager.py    Round-robin + failover across *your own* keys per provider
    audio_extract.py  FFmpeg: mp4 -> wav
    transcription.py  Gladia async STT (fallback: Groq Whisper)
    gemini_service.py Clean transcript / translate to Myanmar / recap / narration rewrite
    tts_service.py     Gemini TTS -> Myanmar speech per segment, speed/pitch via ffmpeg post-processing
    subtitle.py        Build .srt from timed segments
    video_merge.py      FFmpeg: mux new audio + original video (+ optional subtitle burn-in or soft track)
    pipeline.py         Orchestrates the whole job end-to-end, updates progress in Redis + Postgres
worker.py             Background job runner (polls Redis queue, processes jobs)
```

Storage: original uploads + rendered outputs live in `storage/` locally, or an S3-compatible bucket (Cloudflare R2) in production — see `config.py`.

Job progress/queue: Redis (or Upstash Redis's HTTP API when running on Cloudflare, since Workers/Containers can't hold long-lived TCP connections to a classic Redis the same way a normal VM can).

## Local development

```bash
cp .env.example .env        # fill in your own keys
docker compose up --build
# frontend: http://localhost:8080
# api:      http://localhost:8000/docs
```

## Deploying: GitHub → Cloudflare

This repo is set up to run the FastAPI + FFmpeg backend as a **Cloudflare Container** (arbitrary Docker image, not a Worker function), fronted by a lightweight Worker, with the static frontend on **Cloudflare Pages**.

1. Push this repo to GitHub.
2. In the Cloudflare dashboard, connect the repo to **Workers & Pages** (or use the included `.github/workflows/deploy.yml`, which runs `wrangler deploy` on every push to `main`).
3. Set secrets in GitHub (Settings → Secrets → Actions) and/or via `wrangler secret put`:
   `CLOUDFLARE_API_TOKEN`, `CLOUDFLARE_ACCOUNT_ID`, plus everything in `.env.example`.
4. For Postgres, use a serverless-friendly provider reachable from the container (Neon, Supabase, or Cloudflare Hyperdrive in front of either). For the job queue, Upstash Redis (HTTP-based) works well from Containers/Workers.
5. Uploaded/rendered video files go to **Cloudflare R2** (S3-compatible) instead of local disk — see `R2_*` vars in `.env.example`.

`wrangler.jsonc` defines the Container (built from `backend/Dockerfile`) and its binding. Container instance sizing (`standard-2`/`standard-4` etc.) should comfortably handle FFmpeg + a few minutes of video; bump `instance_type`/`max_instances` in `wrangler.jsonc` if you see OOM/timeout on longer clips.

## About the API keys

`config.py` reads **comma-separated lists** of keys per provider (`GLADIA_API_KEYS`, `GROQ_API_KEYS`, `GEMINI_API_KEYS`). `key_manager.py` round-robins across them and skips to the next key on a 429/quota error. This is meant for **keys you legitimately hold** (e.g. you personally have both a Gladia and a Groq key, or a couple of your own Gemini keys) so one slow/rate-limited key doesn't stall a batch job — it is **not** designed to spin up many free-tier accounts to get around a provider's usage limits, which is against Gladia/Groq/Google's terms regardless of how it's wired up technically.

## Extending

- Swap Gladia for Groq (`USE_GROQ_FALLBACK=true`) if you hit Gladia limits — `transcription.py` already does this automatically on repeated failures.
- `tts_service.py` picks from 24 Gemini prebuilt voices (see `GEMINI_VOICES` in `config.py`); speed is applied via `ffmpeg`'s `atempo` and pitch via `asetrate`/resample, since Gemini TTS itself is steered by natural-language style prompts rather than numeric speed/pitch parameters.
- Subtitles: `subtitle.py` builds a standard `.srt`; `video_merge.py` either burns it into the video permanently or muxes it as a toggleable soft subtitle track, depending on the `subtitle_mode` job option.
