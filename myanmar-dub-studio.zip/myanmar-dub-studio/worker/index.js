import { Container } from "cloudflare:workers";

// Wraps the FastAPI + FFmpeg Docker image (backend/Dockerfile) as a Container
// class. The container listens on 8080, matching the Dockerfile's EXPOSE/CMD.
export class DubStudioBackend extends Container {
  defaultPort = 8080;
  // Keep the container warm for a couple minutes after the last request so a
  // batch of uploads doesn't cold-start a fresh instance for every job.
  sleepAfter = "2m";
}

export default {
  async fetch(request, env) {
    const id = env.BACKEND.idFromName("primary");
    const stub = env.BACKEND.get(id);
    return stub.fetch(request);
  },
};
